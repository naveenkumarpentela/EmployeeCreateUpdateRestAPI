package employeeCU.dao;

import employeeCU.model.Employee;
import employeeCU.model.Response;

public interface EmployeeDao {

	public Response createEmployee(Employee employee);
	public Response updateEmployee(Employee employee);
}
