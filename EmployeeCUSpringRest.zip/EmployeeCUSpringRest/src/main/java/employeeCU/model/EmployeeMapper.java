package employeeCU.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EmployeeMapper implements RowMapper<Employee> {

	public Employee mapRow(ResultSet resultSet, int i) throws SQLException {

		Employee employee = new Employee();
		employee.setEmpid(resultSet.getInt("Empid"));
		employee.setEmpName(resultSet.getString("empName"));
		employee.setDepartment(resultSet.getString("department"));
		employee.setJoining_date(resultSet.getString("joining_date"));
		return employee;
	}	
}
