package employeeCU.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import employeeCU.dao.EmployeeDao;
import employeeCU.model.Employee;
import employeeCU.model.Response;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao employeeDao;
	
	@Autowired
	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	public Response createEmployee(Employee employee) {
		return employeeDao.createEmployee(employee);
	}

	public Response updateEmployee(Employee employee) {
		return employeeDao.updateEmployee(employee);
	}
}
