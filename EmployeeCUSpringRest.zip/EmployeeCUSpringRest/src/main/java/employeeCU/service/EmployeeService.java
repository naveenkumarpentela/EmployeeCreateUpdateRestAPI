package employeeCU.service;

import employeeCU.model.Employee;
import employeeCU.model.Response;

public interface EmployeeService {

	public Response createEmployee(Employee employee);

	public Response updateEmployee(Employee employee);
}
