import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;

import employeeCU.controller.EmployeeController;
import employeeCU.model.Employee;
import employeeCU.model.Response;

public class EmployeeServiceJunit {

	private static Employee employee = null;
	Response createResponse = null;
	Response updateResponse = null;
	EmployeeController mockObject = mock(EmployeeController.class);

	@Before
	public void setup() {
		employee = new Employee();
		employee.setDepartment("100");
		employee.setDepartment("IT");
		employee.setEmpName("Employee");
		employee.setJoining_date("2019/10/10");
		createResponse = new Response();
		updateResponse = new Response();
		when(mockObject.createEmployee(employee)).thenReturn((Response) createResponse);
		when(mockObject.updateEmployee(employee)).thenReturn((Response) updateResponse);
	}

	@Test
	public void testCreateEmployee(String xml) {
		assertEquals(createResponse, mockObject.createEmployee(employee));
		assertEquals(updateResponse, mockObject.createEmployee(employee));
		assertEquals(createResponse.getMessage(), "Employee detils inserted and employee got created");
		assertEquals(updateResponse.getMessage(), "Updated Employee details");

	}
}
