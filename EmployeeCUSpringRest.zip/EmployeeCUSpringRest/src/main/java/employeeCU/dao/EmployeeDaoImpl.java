package employeeCU.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Objects;
import java.util.logging.Logger;

import javax.sql.DataSource;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.xml.sax.SAXException;

import employeeCU.model.Employee;
import employeeCU.model.EmployeeMapper;
import employeeCU.model.Response;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	JdbcTemplate jdbcTemplate;
	Logger log;

	private final String SQL_FIND_EMPLOYEE = "select * from employee where Empid = ?";
	private final String SQL_UPDATE_EMPLOYEE = "update employee set empName = ?, department = ?, joining_date  = ? where Empid = ?";
	private final String SQL_INSERT_EMPLOYEE = "insert into employee(Empid, empName, department, joining_date) values(?,?,?,?)";
	private final String SQL_INSERT_ERROR = "insert into error(employeeId, errorMessage, errorStatus, department, joining_date) values(?,?,?,?,?)";

	@Autowired
	public EmployeeDaoImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Autowired
	public void setLog(Logger log) {
		this.log = log;
	}

	public Employee getEmployeeById(int id) {
		return jdbcTemplate.queryForObject(SQL_FIND_EMPLOYEE, new Object[] { id }, new EmployeeMapper());
	}

//	@Autowired
//	public void setJdbcTemplate(JdbcTemplate JdbcTemplate) {
//		this.jdbcTemplate = JdbcTemplate;
//	}

	public Response createEmployee(Employee employee) {
		log.info("Create Employee logic started executing");
		Response response = null;
		boolean valid = false;
		Instant start, end;
		start = calculateTime();
		try {
			response = new Response();
			int count = 0;
			/*
			 * String sqlSelect = "SELECT Empid FROM employee WHERE Empid=?"; Integer
			 * employeeId = (Integer) jdbcTemplate.queryForObject(sqlSelect, new Object[] {
			 * employee.getEmpid() }, Integer.class);
			 */
			log.info("payload validation started executing");
			valid = jaxbObjectToXML(employee);
			log.info("payload validation ended");
			if (valid) {
				log.info("payload is valid validation and started excecuting services");
				Employee employeeRetrieved = getEmployeeById(employee.getEmpid());
				if (employeeRetrieved != null)
					count = 1;
				if (count == 1) {
					response.setStatus(false);
					response.setMessage("Employee Already Exists");
					return response;
				} else {
					int status = jdbcTemplate.update(SQL_INSERT_EMPLOYEE, employee.getEmpid(), employee.getEmpName(),
							employee.getDepartment(), employee.getJoining_date());
					/*
					 * String sql =
					 * "INSERT INTO EMPLOYEE(Empid,empName,department,joining_date,logDateTime) VALUES(:Empid, :empName, :department, :joining_date, :logDateTime);"
					 * jdbcTemplate.update(sql, getSqlParameterByModel(employee));
					 */
					if (status != 0) {
						response.setStatus(true);
						response.setMessage("Employee detils inserted and employee got created");
					}
					return response;
				}
			} else {
				response.setStatus(false);
				response.setMessage("XML is not a valid one");
				log.info("XML is not a valid one");
			}
		} catch (Exception exception) {
			log.info("Something went wrong while creating a customer..!!!");
		}
		end = calculateTime();
		Duration timeElapsed = Duration.between(start, end);
		log.info("TIME TAKEN FOR CREATING A CUSTOMER REQUEST IS --" + timeElapsed);
		return response;
	}

	public Response updateEmployee(Employee employee) {
		Instant start, end;
		start = calculateTime();
		Response response = null;
		try {
			response = new Response();
			Employee employeeRetrieved = getEmployeeById(employee.getEmpid());
			if (employeeRetrieved != null) {
				String joiningDate = employeeRetrieved.getJoining_date();
				if (employeeRetrieved.getJoining_date() != null) {
					Timestamp ts = Timestamp.valueOf(joiningDate);
					Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
					long milliseconds = currentTimeStamp.getTime() - ts.getTime();
					int seconds = (int) milliseconds / 1000;
					int hours = seconds / 3600;
					seconds = (seconds % 3600) % 60;
					if (hours < 24) {
						response.setMessage("system doesn't allow update on employee within a 24 hour period");
						response.setStatus(false);

						int status = jdbcTemplate.update(SQL_INSERT_ERROR, employee.getEmpid(), response.getMessage(),
								response.isStatus(), employee.getDepartment(), employee.getJoining_date());
						if (status != 0) {
							System.out.println("Error logged in Error table");
						}
						return response;
					} else {
						jdbcTemplate.update(SQL_UPDATE_EMPLOYEE, employee.getEmpName(), employee.getDepartment(),
								employee.getJoining_date());
						response.setMessage("Updated Employee details");
						response.setStatus(true);
						return response;
					}
				}
			}
		} catch (Exception e) {

		}
		/*
		 * String sqlSelect = "SELECT logDateTime FROM employee WHERE Empid=?";
		 * Timestamp logDateTime = (Timestamp) jdbcTemplate.queryForObject(sqlSelect,
		 * new Object[] { employee.getEmpid() }, Timestamp.class); if (logDateTime !=
		 * null) { Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
		 * long milliseconds = currentTimeStamp.getTime() - logDateTime.getTime(); int
		 * seconds = (int) milliseconds / 1000; int hours = seconds / 3600; seconds =
		 * (seconds % 3600) % 60; // if time difference is less than 24 hrs send status
		 * and add Restricted status // in table if (hours < 24) { response.
		 * setMessage("system doesn't allow update on employee in a 24 hour period");
		 * response.setStatus(false); String sql =
		 * "UPDATE employeeStatus SET status = 'Restricted', message = 'system doesnt allow update on employee in a 24 hour period' WHERE Empid = :Empid"
		 * ; jdbcTemplate.update(sql); return response; // if time difference is greater
		 * than 24 hrs else part will be executed } else { String sql =
		 * "UPDATE employee SET empName = :empName, department = :department, joining_date = :joining_date WHERE Empid = :Empid"
		 * ; jdbcTemplate.update(sql, getSqlParameterByModel(employee));
		 * response.setMessage("Updated Employee details"); response.setStatus(true);
		 * return response; } }
		 */
		end = calculateTime();
		Duration timeElapsed = Duration.between(start, end);
		log.info("TIME TAKEN FOR UPDATING A CUSTOMER REQUEST IS --" + timeElapsed);
		return response;

	}

	/*
	 * private SqlParameterSource getSqlParameterByModel(Employee employee) {
	 * java.util.Date date = new java.util.Date(); MapSqlParameterSource
	 * parameterSource = new MapSqlParameterSource(); if (employee != null) {
	 * parameterSource.addValue("Empid", employee.getEmpid());
	 * parameterSource.addValue("empName", employee.getEmpName());
	 * parameterSource.addValue("department", employee.getDepartment());
	 * parameterSource.addValue("joining_date", employee.getJoining_date());
	 * parameterSource.addValue("logDateTime", new Timestamp(date.getTime())); }
	 * return parameterSource; }
	 */

	private boolean validate(String xmlFile, String schemaFile) {
		Instant start, end;
		SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		try {
			start = calculateTime();
			log.info("Validation started");
			Schema schema = schemaFactory.newSchema(new File(getResource(schemaFile)));

			Validator validator = schema.newValidator();
			validator.validate(new StreamSource(new File(getResource(xmlFile))));
			log.info("Validation Ended");
			end = calculateTime();
			Duration timeElapsed = Duration.between(start, end);
			log.info("TIME TAKEN FOR VALIDATING A REQUEST IS --" + timeElapsed);
			return true;
		} catch (SAXException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	private String getResource(String filename) throws FileNotFoundException {
		URL resource = getClass().getClassLoader().getResource(filename);
		Objects.requireNonNull(resource);

		return resource.getFile();
	}

	private boolean jaxbObjectToXML(Employee employee) {
		boolean valid = false;
		Instant start, end;
		try {
			start = calculateTime();
			log.info("Object to XML conversion Started");
			// Create JAXB Context
			JAXBContext jaxbContext = JAXBContext.newInstance(Employee.class);

			// Create Marshaller
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// Required formatting??
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

			// Print XML String to Console
			StringWriter sw = new StringWriter();

			// Write XML to StringWriter
			jaxbMarshaller.marshal(employee, sw);

			// Verify XML Content
			String xmlContent = sw.toString();
			System.out.println("xmlContent is --> " + xmlContent);

			valid = validate(xmlContent, "E:\\Naveen\\Workspace\\EmployeeExample\\WebContent\\WEB-INF\\employee.xsd");
			log.info("Object to XML conversion ended");
			end = calculateTime();
			Duration timeElapsed = Duration.between(start, end);
			log.info("TIME TAKEN FOR XML CONVERSION USING JAXB IS --" + timeElapsed);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return valid;
	}

	public Instant calculateTime() {
		Instant time = Instant.now();
		return time;
	}
}
