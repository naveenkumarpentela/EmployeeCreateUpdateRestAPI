package employeeCU.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

public class EmployeeServiceClient {

	public static void main(String[] args) {
		EmployeeRetryStrategy retry = new EmployeeRetryStrategy();
		String myURL = "http://localhost:2019/EmployeeCUSpringRest/employeeCU/createEmployee";
		while (retry.shouldRetry()) {
			System.out.println("Requested URL is --> " + myURL);
			StringBuilder sb = new StringBuilder();
			HttpURLConnection urlConn = null;
			InputStreamReader in = null;
			try {
				URL url = new URL(myURL);
				urlConn = (HttpURLConnection) url.openConnection();
				if (urlConn != null) {
					urlConn.setRequestMethod("GET");
					urlConn.setRequestProperty("Empid", "100");
					urlConn.setRequestProperty("empName", "Cognizant");
					urlConn.setRequestProperty("department", "IT");
					urlConn.setRequestProperty("joining_date", "2018/10/10");
					urlConn.setReadTimeout(60 * 1000);
				}
				if (urlConn != null && urlConn.getInputStream() != null) {
					in = new InputStreamReader(urlConn.getInputStream(), Charset.defaultCharset());
					BufferedReader bufferedReader = new BufferedReader(in);
					if (bufferedReader != null) {
						int cp;
						while ((cp = bufferedReader.read()) != -1) {
							sb.append((char) cp);
						}
						bufferedReader.close();
					}
				}
				System.out.println(sb.toString());
				// logic for 3 retries
				if (urlConn.getResponseCode() > 500) {
					retry.errorOccured();
				}
				in.close();
				break;

			} catch (Exception e) {
				try {
					System.out.println("in catch.....");
					retry.errorOccured();
				} catch (RuntimeException e1) {
					throw new RuntimeException("Exception while calling URL:" + myURL, e);
				} catch (Exception e1) {
					throw new RuntimeException(e1);
				}
			}
		}
	}

	static class EmployeeRetryStrategy {
		public static final int DEFAULT_RETRIES = 3;
		public static final long DEFAULT_WAIT_TIME_IN_MILLI = 600;

		private int numberOfRetries;
		private int numberOfTriesLeft;
		private long timeToWait;

		public EmployeeRetryStrategy() {
			this(DEFAULT_RETRIES, DEFAULT_WAIT_TIME_IN_MILLI);
		}

		public EmployeeRetryStrategy(int numberOfRetries, long timeToWait) {
			this.numberOfRetries = numberOfRetries;
			numberOfTriesLeft = numberOfRetries;
			this.timeToWait = timeToWait;
		}

		/**
		 * @return true if there are tries left
		 */
		public boolean shouldRetry() {
			return numberOfTriesLeft > 0;
		}

		public void errorOccured() throws Exception {
			numberOfTriesLeft--;
			if (!shouldRetry()) {
				throw new Exception("Retry Failed: Total " + numberOfRetries + " attempts made at interval "
						+ getTimeToWait() + "ms");
			}
			waitUntilNextTry();
		}

		public long getTimeToWait() {
			return timeToWait;
		}

		private void waitUntilNextTry() {
			try {
				Thread.sleep(getTimeToWait());
			} catch (InterruptedException ignored) {
			}
		}
	}
}
